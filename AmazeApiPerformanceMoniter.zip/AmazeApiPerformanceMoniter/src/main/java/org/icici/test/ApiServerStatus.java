package org.icici.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.SocketTimeoutException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.AllowAllHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.icici.db.DatabaseConnection;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class ApiServerStatus {
	
	public static JsonObject getResponse(String url){
		//System.out.println(url);
		JsonObject responseJson = null ;
		long startTime = 0L;
		long endTime = 0L;
		
		try{
		SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
		    public boolean isTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
		        return true;
		    }
		}).build();
		HostnameVerifier hostnameVerifier = SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER;

		SSLConnectionSocketFactory sslSocketFactory = new SSLConnectionSocketFactory(sslContext, hostnameVerifier);
		Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory>create()
		        .register("http", PlainConnectionSocketFactory.getSocketFactory())
		        .register("https", sslSocketFactory)
		        .build();

		RequestConfig requestConfig = RequestConfig.custom()
				  //.setConnectTimeout(300000)  //Server Timeout time
				  //.setSocketTimeout(100)
				  .build();
		
		HttpClient client = HttpClients.custom()
				.setSslcontext(sslContext)
				.setSSLHostnameVerifier(new AllowAllHostnameVerifier())
				.setDefaultRequestConfig(requestConfig)
                //.setConnectionManager(connMgr)
                .build();
		
		HttpGet request = new HttpGet(url);
		
		startTime = new Date().getTime();
		HttpResponse response = client.execute(request);		
		endTime = new Date().getTime();
		String apiResponse = IOUtils.toString(response.getEntity().getContent());
		responseJson = new JsonParser().parse(apiResponse).getAsJsonObject();
		
		responseJson.addProperty("startTime", startTime);
		responseJson.addProperty("endTime", endTime);
		responseJson.addProperty("difference", endTime-startTime);
		
		}catch(ConnectTimeoutException | SocketTimeoutException cte){
			cte.printStackTrace();
		}
		catch(HttpHostConnectException cr){
			cr.printStackTrace();
		}
		catch(KeyManagementException | NoSuchAlgorithmException |KeyStoreException| IOException ex){
			ex.printStackTrace();
		}
		
		return responseJson;		
	}
	
	public static JsonObject getServerStatus(String url) {		
		int retry =0;
		JsonObject responseObj = getResponse(url);
		//System.out.println(responseObj);
		/*try {
			
			while (responseObj.has("ERROR_CODE")&& responseObj.get("ERROR_CODE").getAsString().equalsIgnoreCase("E01")) {
				//System.out.println(responseObj.get("ERROR_CODE").getAsString());
				retry++;
				//System.out.println("Retrying : " + retry);
				responseObj = getResponse(url);
			}
		} catch (Exception e) {
			System.out.println(responseObj);
			e.printStackTrace();
		}*/
		responseObj.addProperty("retryCount", retry);
		return responseObj;
	}
	
	public static void main(String[] args) {
		String subject = " iMobileNXT - User Data Catching";
		String toAddr = "debashish.barai@icicibank.com, shriram.perumal@icicibank.com, sasikumar.r@ext.icicibank.com, ashrumochan.behera@ext.icicibank.com";
		String message = "<html> <p>Hi Team, <br><br>API Data catching done for all IMobile users. <br><br>Thanks and Regards, <br>Ashrumochan Behera </p> </html>";
		
		System.out.println("Start Time :- "+new Date());
		int lower=Integer.parseInt(args[0]);
		int higher=Integer.parseInt(args[1]);
		
		try{
			Connection con = DatabaseConnection.getConnction();
			Connection updateCon = DatabaseConnection.getConnction();
			
			Map<String,String> urlMapping = new HashMap<String,String>();
			urlMapping.put("Dashboard (Discover New)","https://imnxtanalytics.icicibankltd.com/amaze/rest/api/getDashboard?USERID={0}&RRN=123123&CHANNEL=abc&MOBILE=123456789");
			urlMapping.put("Spending Analysis (+ Spending Overview)","https://imnxtanalytics.icicibankltd.com/amaze/rest/api/getOverview?USERID={0}&RRN=123123&CHANNEL=abc&MOBILE=123456789");
			urlMapping.put("Transaction Timeline","https://imnxtanalytics.icicibankltd.com/amaze/rest/api/getTransactions?USERID={0}&RRN=123123&CHANNEL=abc&MOBILE=123456789");
			urlMapping.put("Recommendation","https://imnxtanalytics.icicibankltd.com/amaze/rest/api/getRecommendation?USERID={0}&RRN=123123&CHANNEL=abc&MOBILE=123456789");
			urlMapping.put("Upcoming Events","https://imnxtanalytics.icicibankltd.com/amaze/rest/api/getUpcomingTransactions?USERID={0}&RRN=123123&CHANNEL=abc&MOBILE=123456789");
			urlMapping.put("SR / Deliverables","https://imnxtanalytics.icicibankltd.com/amaze/rest/api/getSRStatus?USERID={0}&RRN=123123&CHANNEL=abc&MOBILE=123456789");			
			//urlMapping.put("Category Master","https://imnxtanalytics.icicibankltd.com/amaze/rest/api/getCategoryList?USERID={0}&RRN=123123&CHANNEL=abc&MOBILE=123456789");
			//urlMapping.put("Credit Card", "https://imnxtanalytics.icicibankltd.com/amaze/rest/api/getCreditCardOverview?USERID={0}&RRN=123123&CHANNEL=abc&MOBILE=123456789");
			
			String query = "select * from EDW.AMAZE_API_USERID where seq_no between "+lower+" and "+higher+" order by 2";
			ResultSet rs = DatabaseConnection.getResult(query, con);
			query = "insert into EDW.AMAZE_API_PERFORMANCE_HISTORY_ALL_USERS values(?, ?, ? ,?, ?, ?, ?)";
			PreparedStatement ps = updateCon.prepareStatement(query);
			int batch =0;
			while(rs.next()){
				String user = rs.getString("USER_ID");
				System.out.println("Executing for user:- "+user);
				for(String key : urlMapping.keySet()){
					try{
					JsonObject responseObj = getServerStatus(MessageFormat.format(urlMapping.get(key),user));
					ps.setString(1, key);
					ps.setString(2, user);
					ps.setDate(3, new java.sql.Date(new Date().getTime()));
					ps.setTimestamp(4, new java.sql.Timestamp(responseObj.get("startTime").getAsLong()));
					ps.setTimestamp(5, new java.sql.Timestamp(responseObj.get("endTime").getAsLong()));
					ps.setLong(6, responseObj.get("difference").getAsLong());
					ps.setLong(7, responseObj.get("retryCount").getAsLong());
					ps.addBatch();
					batch++;
					}catch(Exception e){
						System.out.println("Exception in Batch "+e.getMessage());
						e.printStackTrace();
					}
				}
				try {
					if (batch >= 5000) {
						ps.executeBatch();
						ps.clearBatch();
						batch = 0;
					}
				} catch (Exception ex) {
					System.out.println("Exception occured in Inserting");
					ex.printStackTrace();
				}
			}
			ps.executeBatch();
			
			rs.close();
			con.close();
			updateCon.close();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		System.out.println("End Time :- "+new Date());
		//sendMail(message, subject, toAddr);
		
	}
	

	public static void sendMail(String message,String subject,String toAddr) {

		//System.out.println(message);
		write(message);
        
        StringBuffer bf = new StringBuffer();
        try {
        	System.out.println("Sending Mail");
        	//System.out.println(subject);
        	//System.out.println(message);
        	//toAddr = "mbsupport@icicibank.com, sasikumar.r@ext.icicibank.com, shriram.perumal@icicibank.com, shashank.gangadharbhatla@icicibank.com, debashish.barai@icicibank.com, ashrumochan.behera@ext.icicibank.com,mongosupport@icicibank.com";
        	//toAddr = "shriram.perumal@icicibank.com, debashish.barai@icicibank.com, ashrumochan.behera@ext.icicibank.com";
            Process p = Runtime.getRuntime().exec(new String[] { "bash", "-c", "( echo \"To:"+toAddr+"\";"
                    + "    echo \"Subject: "+subject+" \";"
                    + "    echo \"Content-Type: text/html\";" 
                    + "    echo \"MIME-Version: 1.0\";"
                    + "    echo ; "
                    + " cat /vertica_load/amaze_api_performance_monitor/all_users/performance.html"  
                    + " ) | sendmail -t " });
            BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = input.readLine()) != null) {
                bf.append(line);
            }
            System.out.println(bf.toString());
            System.out.println("Mail Sent");
        } catch (Exception e) {
        	e.printStackTrace();
            System.out.println("IOException in Process");
        }
        
    }
	
	public static void write(String text){
		String localPath="C:/Users/BAN97267/Desktop/test1.html";
		//String serverPath="/vertica_load/amaze_api_performance_monitor/performance.html";
		String serverPath="/vertica_load/amaze_api_performance_monitor/all_users/performance.html";
		
		//File file = new File(localPath);
		File file = new File(serverPath);
        FileWriter fr = null;
        try {
            fr = new FileWriter(file);
            fr.write(text);
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            try {
                fr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
	}

}
