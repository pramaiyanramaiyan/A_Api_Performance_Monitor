package org.icici.test;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.icici.db.DatabaseConnection;

public class ApiLoadTest {

	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
		// TODO Auto-generated method stub
		
		StringBuffer transactionTimeline = new StringBuffer(); 
		StringBuffer discover  = new StringBuffer(); 
		StringBuffer recommendation = new StringBuffer(); 
		StringBuffer upcomingExpenses = new StringBuffer(); 
		StringBuffer srDeliverable = new StringBuffer(); 
		
		Connection con = DatabaseConnection.getConnction();
		String boundary[] = new String[]{ " 0 and 1000 "," 1001 and 2000 "," 2001 and 3000 ",
				              " 3001 and 4000 "," 4001 and 5000 "," 5001 and 8000 ",
				              " 8001 and 10000 "," 10001 and 20000 "
				             };
		String tableName = "EDW.Amaze_old_api_test_23_may_1500";
		for(String cond:boundary){
			System.out.println("Running for "+cond);
			String query = "select A.*,B.min_response,B.max_response from "
					+ " ("
					+ "    select distinct function, median(response_time) over (partition by function) as Median_response"
					+ "    from "+tableName
					+ "    where userid in (SELECT USER_ID FROM RECONP.AMAZE_PERF_TESTING_USER_ID where count between "+cond+")"
					+ "    group by response_time,function"
					+ " ) A"
					+ " Join"
					+ " ("
					+ "    select function, min(response_time) min_response,max(response_time) max_response"
					+ "    from "+tableName
					+ "    where userid in (SELECT USER_ID FROM RECONP.AMAZE_PERF_TESTING_USER_ID where count between "+cond+")"
					+ "    group by function"
					+ " ) B "
					+ " on A.function=b.function";
			ResultSet rs = DatabaseConnection.getResult(query, con);
			while(rs.next()){
				String functionName = rs.getString("function");

				if(functionName.equalsIgnoreCase("getDashboard")){
					discover.append("\n"+functionName+"\t"+cond + "\t"+rs.getDouble("Median_response") + "\t"+rs.getInt("min_response") + "\t"+rs.getInt("max_response"));
					
				}
				else if(functionName.equalsIgnoreCase("getRecommendation")){
					recommendation.append("\n"+functionName+"\t"+cond + "\t"+rs.getDouble("Median_response") + "\t"+rs.getInt("min_response") + "\t"+rs.getInt("max_response"));
					
				}else if(functionName.equalsIgnoreCase("getSRStatus")){
					srDeliverable.append("\n"+functionName+"\t"+cond + "\t"+rs.getDouble("Median_response") + "\t"+rs.getInt("min_response") + "\t"+rs.getInt("max_response"));
					
				}else if(functionName.equalsIgnoreCase("getTransactions")){
					transactionTimeline.append("\n"+functionName+"\t"+cond + "\t"+rs.getDouble("Median_response") + "\t"+rs.getInt("min_response") + "\t"+rs.getInt("max_response"));
					
				}else if(functionName.equalsIgnoreCase("getUpcomingTransactions")){
					upcomingExpenses.append("\n"+functionName+"\t"+cond + "\t"+rs.getDouble("Median_response") + "\t"+rs.getInt("min_response") + "\t"+rs.getInt("max_response"));
					
				}
			}
			rs.close();
		}
		
		
		System.out.println("\n\nFinal Output\n\n");
		System.out.println("Get Transactions \n"+transactionTimeline);
		System.out.println("Discover \n"+discover);
		System.out.println("Recommendation \n"+recommendation);
		System.out.println("Upcoming Expenses \n"+upcomingExpenses);
		System.out.println("SR Status \n"+srDeliverable);
		con.close();
		
	}

}
