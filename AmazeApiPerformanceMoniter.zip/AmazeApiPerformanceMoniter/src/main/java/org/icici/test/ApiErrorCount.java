package org.icici.test;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.icici.db.DatabaseConnection;

public class ApiErrorCount {

	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
		// TODO Auto-generated method stub
		
		StringBuffer transactionTimeline = new StringBuffer(); 
		StringBuffer discover  = new StringBuffer(); 
		StringBuffer recommendation = new StringBuffer(); 
		StringBuffer upcomingExpenses = new StringBuffer(); 
		StringBuffer srDeliverable = new StringBuffer(); 
		
		Connection con = DatabaseConnection.getConnction();
		String boundary[] = new String[]{ " 0 and 1000 "," 1001 and 2000 "," 2001 and 3000 ",
				              " 3001 and 4000 "," 4001 and 5000 "," 5001 and 8000 ",
				              " 8001 and 10000 "," 10001 and 20000 "
				             };
		String tableName = "EDW.Amaze_old_api_test_23_may_1500";
		
		for(String cond:boundary){
			System.out.println("Running for "+cond);
			int mainCount=0;
			String query = "select function,count(distinct userid) as occurance  from "+tableName
					+ " where error='E01' and userid in (SELECT USER_ID FROM RECONP.AMAZE_PERF_TESTING_USER_ID where count between "+cond+" ) "
					+ " group by function";
			
			ResultSet rs = DatabaseConnection.getResult(query, con);
			int discoverCount = 0;
			int recommendationCount = 0;
			int srDeliverableCount = 0;
			int transactionTimelineCount = 0;
			int upcomingExpensesCount = 0;
			while(rs.next()){
				String functionName = rs.getString("function");

				if(functionName.equalsIgnoreCase("getDashboard")){
					discoverCount=rs.getInt("occurance");					
				}
				else if(functionName.equalsIgnoreCase("getRecommendation")){
					recommendationCount=rs.getInt("occurance");					
				}else if(functionName.equalsIgnoreCase("getSRStatus")){
					srDeliverableCount=rs.getInt("occurance");
					
				}else if(functionName.equalsIgnoreCase("getTransactions")){
					transactionTimelineCount=rs.getInt("occurance");					
				}else if(functionName.equalsIgnoreCase("getUpcomingTransactions")){
					upcomingExpensesCount=rs.getInt("occurance");					
				}
			}
			discover.append("\n"+"getDashboard"+"\t"+cond + "\t"+discoverCount);
			recommendation.append("\n"+"getRecommendation"+"\t"+cond + "\t"+recommendationCount);
			srDeliverable.append("\n"+"getSRStatus"+"\t"+cond + "\t"+srDeliverableCount);
			transactionTimeline.append("\n"+"getTransactions"+"\t"+cond + "\t"+transactionTimelineCount);
			upcomingExpenses.append("\n"+"getUpcomingTransactions"+"\t"+cond + "\t"+upcomingExpensesCount);
			rs.close();
		}
		
		
		System.out.println("\n\nFinal Output\n\n");
		System.out.println("Get Transactions \n"+transactionTimeline);
		System.out.println("Discover \n"+discover);
		System.out.println("Recommendation \n"+recommendation);
		System.out.println("Upcoming Expenses \n"+upcomingExpenses);
		System.out.println("SR Status \n"+srDeliverable);	
		
		con.close();
		
	}

}
