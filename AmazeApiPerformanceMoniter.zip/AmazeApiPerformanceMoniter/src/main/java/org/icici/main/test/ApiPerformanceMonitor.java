package org.icici.main.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.AllowAllHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.icici.db.DatabaseConnection;

public class ApiPerformanceMonitor {

	public static void main(String[] args) throws Exception {

		Connection con = DatabaseConnection.getConnction();
		Connection updateCon = DatabaseConnection.getConnction();
		
		ApiPerformanceMonitor http = new ApiPerformanceMonitor();
		Map<String,String> urlMapping = new HashMap<String,String>();
		urlMapping.put("Dashboard (Discover New)","https://imnxtanalytics.icicibankltd.com/amaze/rest/api/getDashboard?USERID={0}&RRN=123123&CHANNEL=abc&MOBILE=123456789");
		urlMapping.put("Spending Analysis (+ Spending Overview)","https://imnxtanalytics.icicibankltd.com/amaze/rest/api/getOverview?USERID={0}&RRN=123123&CHANNEL=abc&MOBILE=123456789");
		urlMapping.put("Recommendation","https://imnxtanalytics.icicibankltd.com/amaze/rest/api/getRecommendation?USERID={0}&RRN=123123&CHANNEL=abc&MOBILE=123456789");
		urlMapping.put("Upcoming Events","https://imnxtanalytics.icicibankltd.com/amaze/rest/api/getUpcomingTransactions?USERID={0}&RRN=123123&CHANNEL=abc&MOBILE=123456789");
		urlMapping.put("SR / Deliverables","https://imnxtanalytics.icicibankltd.com/amaze/rest/api/getSRStatus?USERID={0}&RRN=123123&CHANNEL=abc&MOBILE=123456789");
		urlMapping.put("Transaction Timeline","https://imnxtanalytics.icicibankltd.com/amaze/rest/api/getTransactions?USERID={0}&RRN=123123&CHANNEL=abc&MOBILE=123456789");
		urlMapping.put("Category Master","https://imnxtanalytics.icicibankltd.com/amaze/rest/api/getCategoryList?USERID={0}&RRN=123123&CHANNEL=abc&MOBILE=123456789");
		urlMapping.put("Credit Card", "https://imnxtanalytics.icicibankltd.com/amaze/rest/api/getCreditCardOverview?USERID={0}&RRN=123123&CHANNEL=abc&MOBILE=123456789");
		
		/*String userArr[] = new String[]{"ARVINDBA098","GANAPATH1612","SHREERAMUNIQ139","507288355"};
		Random random = new Random();
		int element = random.nextInt(userArr.length);
		String user =userArr[element];*/

		String query = "select USER_ID,MAPPING_ID from EDW.AMAZE_SAS_DASHBOARD_MAPPING ";
		String condition = " where MAPPING_ID in('CUSTOMER 1', 'CUSTOMER 2', 'CUSTOMER 3', 'CUSTOMER 4', 'CUSTOMER 5', 'CUSTOMER 6', 'CUSTOMER 7', 'CUSTOMER 8', 'CUSTOMER 9','CUSTOMER 10') order by mapping_id";
		ResultSet rs = DatabaseConnection.getResult(query+condition, con);
		//API,User ID (masked),Date,Start Time,End Time,Response Time (in milli second),Benchmark time (milli second)
		query = "insert into EDW.AMAZE_API_PERFORMANCE_HISTORY values(?, ?, ? ,?, ?, ?, ?)";
		PreparedStatement ps = updateCon.prepareStatement(query);
		StringBuffer mailResponse = new StringBuffer();
		//mailResponse.append("<html> \n <head> <style> @-webkit-keyframes blink {     50% {         background: rgba(255, 0, 0, 0.5);     } } @-moz-keyframes blink {     50% {         background: rgba(255, 0, 0, 0.5);     } } @keyframes blink {     50% {         background: rgba(255, 0, 0, 0.5);     } } .blink {     -webkit-animation-direction: normal;     -webkit-animation-duration: 1s;     -webkit-animation-iteration-count: infinite;     -webkit-animation-name: blink;     -webkit-animation-timing-function: linear;     -moz-animation-direction: normal;     -moz-animation-duration: 1s;     -moz-animation-iteration-count: infinite;     -moz-animation-name: blink;     -moz-animation-timing-function: linear;     animation-direction: normal;     animation-duration: 5s;     animation-iteration-count: infinite;     animation-name: blink;     animation-timing-function: linear; }  table {     background: white;     border: 1px solid black;     border-collapse: collapse;     border-color: black;     border-spacing: 1px; 	     font-family: Calibri; } th {         border: 2px solid black;     background-color: #000066; 	     color: white; 	     padding: 3px     } tr td{         border: 1px solid black;     color: black; 	     padding: 3px     }</style> \n</head> \n<body> \n<p> Dear All, \n<br><br>&emsp;&emsp;Please find the iMobile NXT - API Response Time log below </p> \n<table>    <tr>     <th>#</th>     <th>API</th>     <th>User ID</th> 	<th>Date</th> 	<th>Start Time</th> 	<th>End Time</th> 	<th>Response Time<br>(in milli second)</th> 	<th>Benchmark time<br>(in milli second)</th>   </tr>");
		mailResponse.append("<html> \n <head> <style>table {     background: white;     border: 1px solid black;     border-collapse: collapse;     border-color: black;     border-spacing: 1px; 	     font-family: Calibri; } th {         border: 2px solid black;     background-color: #000066; 	     color: white; 	     padding: 3px     } tr td{         border: 1px solid black;     color: black; 	     padding: 3px; text-align: center;     }</style> \n</head> \n<body> \n"
				+ " <p> Dear All, \n<br><br>&emsp;&emsp;Please find the iMobile NXT - API Response Time log below "
				+ " <br>&emsp;&emsp;Listed are all API's for which we need to check the reason behind high response time.</p> "
				+ " \n<table>    <tr>     <th>#</th>     <th>API</th>     <th>User ID</th><th>Start Time</th> 	<th>End Time</th> 	<th>Response Time<br>(in milli second)</th> 	<th>Benchmark time<br>(in milli second)</th>   </tr>");
		int slNumber=1;
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss.SSS a");
		while(rs.next()){
			String user = rs.getString("USER_ID");
			String mappedUser = rs.getString("MAPPING_ID");
			
			for(String s : urlMapping.keySet()){
				Map<String,Long> response = http.sendGet(MessageFormat.format(urlMapping.get(s),user));
				//API,USER_ID,EXECUTION_DATE,EXECUTION_START_TIME,EXECUTION_COMPLETE_TIME,RESPONSE_TIME,BENCHMARK_TIME
				/*System.out.println(s+" "+user+" "+new Date()+" "+
									response.get("startTime")+" "+
									response.get("endTime")+" "+
									response.get("difference")+" "+
									200);   */
				ps.setString(1, s);
				ps.setString(2, mappedUser);
				ps.setDate(3, new java.sql.Date(new Date().getTime()));
				ps.setTimestamp(4, new java.sql.Timestamp(response.get("startTime")));
				ps.setTimestamp(5, new java.sql.Timestamp(response.get("endTime")));
				ps.setLong(6, response.get("difference"));
				ps.setInt(7, 200);
				ps.addBatch();
				//As suggested by Debashish Changed bench mark Time to 200ms
				if(response.get("difference")>200L){
					mailResponse.append("\n<tr><td>"+slNumber+"</td><td>"+s+"</td><td>"+mappedUser
							//+"</td><td>"+new java.sql.Date(new Date().getTime())
							+"</td><td>"+dateFormat.format(new Date(response.get("startTime")))
							+"</td><td>"+dateFormat.format(new Date(response.get("endTime")))
							+"</td><td>"+response.get("difference")
							+"</td><td>"+200+"</td></tr>");
					slNumber++;
				}
				else{
					/*mailResponse.append("<tr><td>"+slNumber+"</td><td>"+s+"</td><td>"+mappedUser
					 		+"</td><td>"+new java.sql.Date(new Date().getTime())
							+"</td><td>"+dateFormat.format(new Date(response.get("startTime")))
							+"</td><td>"+dateFormat.format(new Date(response.get("endTime")))
							+"</td><td>"+response.get("difference")
							+"</td><td>"+200+"</td></tr>");*/					
				}
				
				//slNumber++;
			}			
		}
		mailResponse.append("\n</table> \n <p style=\"color:gray\"><br>Thanks and Regards,<br>Big Data Team</p></body> \n</html>");
		//System.out.println(mailResponse.toString());
		ps.executeBatch();
		write(mailResponse.toString());
		sendMail(mailResponse.toString());
	}
	public static void main123(String[] args) {
		String message = "<html> <head> <style> @-webkit-keyframes blink {     50% {         background: rgba(255, 0, 0, 0.5);     } } @-moz-keyframes blink {     50% {         background: rgba(255, 0, 0, 0.5);     } } @keyframes blink {     50% {         background: rgba(255, 0, 0, 0.5);     } } .blink {     -webkit-animation-direction: normal;     -webkit-animation-duration: 1s;     -webkit-animation-iteration-count: infinite;     -webkit-animation-name: blink;     -webkit-animation-timing-function: linear;     -moz-animation-direction: normal;     -moz-animation-duration: 1s;     -moz-animation-iteration-count: infinite;     -moz-animation-name: blink;     -moz-animation-timing-function: linear;     animation-direction: normal;     animation-duration: 5s;     animation-iteration-count: infinite;     animation-name: blink;     animation-timing-function: linear; }  table {     background: white;     border: 1px solid black;     border-collapse: collapse;     border-color: black;     border-spacing: 1px; 	     font-family: Calibri; } th {         border: 2px solid black;     background-color: #000066; 	     color: white; 	     padding: 3px     } tr td{         border: 1px solid black;     color: black; 	     padding: 3px     }</style> </head> <body> <p> Dear All, <br><br>&emsp;&emsp;Please find the iMobile NXT - API Response Time log below </p> <table>    <tr>     <th>#</th>     <th>API</th>     <th>User ID</th> 	<th>Date</th> 	<th>Start Time</th> 	<th>End Time</th> 	<th>Response Time<br>(in milli second)</th> 	<th>Benchmark time<br>(in milli second)</th>   </tr><tr class=blink><td>1</td><td>Credit Card</td><td>CUSTOMER 1</td><td>2018-02-28</td><td>28-02-2018 11:39:00.291 AM</td><td>28-02-2018 11:39:02.536 AM</td><td>2245</td><td>100</td></tr><tr class=blink><td>2</td><td>Dashboard (Discover New)</td><td>CUSTOMER 1</td><td>2018-02-28</td><td>28-02-2018 11:39:02.646 AM</td><td>28-02-2018 11:39:03.116 AM</td><td>470</td><td>100</td></tr><tr><td>3</td><td>SR / Deliverables</td><td>CUSTOMER 1</td><td>2018-02-28</td><td>28-02-2018 11:39:03.178 AM</td><td>28-02-2018 11:39:03.241 AM</td><td>63</td><td>100</td></tr><tr class=blink><td>4</td><td>Transaction Timeline</td><td>CUSTOMER 1</td><td>2018-02-28</td><td>28-02-2018 11:39:03.256 AM</td><td>28-02-2018 11:39:03.381 AM</td><td>125</td><td>100</td></tr><tr><td>5</td><td>Upcoming Events</td><td>CUSTOMER 1</td><td>2018-02-28</td><td>28-02-2018 11:39:03.397 AM</td><td>28-02-2018 11:39:03.443 AM</td><td>46</td><td>100</td></tr><tr class=blink><td>6</td><td>Spending Analysis (+ Spending Overview)</td><td>CUSTOMER 1</td><td>2018-02-28</td><td>28-02-2018 11:39:03.459 AM</td><td>28-02-2018 11:39:05.443 AM</td><td>1984</td><td>100</td></tr><tr class=blink><td>7</td><td>Category Master</td><td>CUSTOMER 1</td><td>2018-02-28</td><td>28-02-2018 11:39:05.475 AM</td><td>28-02-2018 11:39:20.051 AM</td><td>14576</td><td>100</td></tr><tr><td>8</td><td>Recommendation</td><td>CUSTOMER 1</td><td>2018-02-28</td><td>28-02-2018 11:39:20.192 AM</td><td>28-02-2018 11:39:20.239 AM</td><td>47</td><td>100</td></tr><tr class=blink><td>9</td><td>Credit Card</td><td>CUSTOMER 10</td><td>2018-02-28</td><td>28-02-2018 11:39:20.239 AM</td><td>28-02-2018 11:39:20.364 AM</td><td>125</td><td>100</td></tr><tr class=blink><td>10</td><td>Dashboard (Discover New)</td><td>CUSTOMER 10</td><td>2018-02-28</td><td>28-02-2018 11:39:20.379 AM</td><td>28-02-2018 11:39:21.003 AM</td><td>624</td><td>100</td></tr><tr><td>11</td><td>SR / Deliverables</td><td>CUSTOMER 10</td><td>2018-02-28</td><td>28-02-2018 11:39:21.035 AM</td><td>28-02-2018 11:39:21.081 AM</td><td>46</td><td>100</td></tr><tr><td>12</td><td>Transaction Timeline</td><td>CUSTOMER 10</td><td>2018-02-28</td><td>28-02-2018 11:39:21.082 AM</td><td>28-02-2018 11:39:21.160 AM</td><td>78</td><td>100</td></tr><tr><td>13</td><td>Upcoming Events</td><td>CUSTOMER 10</td><td>2018-02-28</td><td>28-02-2018 11:39:21.176 AM</td><td>28-02-2018 11:39:21.223 AM</td><td>47</td><td>100</td></tr><tr class=blink><td>14</td><td>Spending Analysis (+ Spending Overview)</td><td>CUSTOMER 10</td><td>2018-02-28</td><td>28-02-2018 11:39:21.238 AM</td><td>28-02-2018 11:39:22.112 AM</td><td>874</td><td>100</td></tr><tr class=blink><td>15</td><td>Category Master</td><td>CUSTOMER 10</td><td>2018-02-28</td><td>28-02-2018 11:39:22.175 AM</td><td>28-02-2018 11:39:36.938 AM</td><td>14763</td><td>100</td></tr><tr><td>16</td><td>Recommendation</td><td>CUSTOMER 10</td><td>2018-02-28</td><td>28-02-2018 11:39:37.017 AM</td><td>28-02-2018 11:39:37.068 AM</td><td>51</td><td>100</td></tr><tr class=blink><td>17</td><td>Credit Card</td><td>CUSTOMER 2</td><td>2018-02-28</td><td>28-02-2018 11:39:37.084 AM</td><td>28-02-2018 11:39:37.474 AM</td><td>390</td><td>100</td></tr><tr class=blink><td>18</td><td>Dashboard (Discover New)</td><td>CUSTOMER 2</td><td>2018-02-28</td><td>28-02-2018 11:39:37.552 AM</td><td>28-02-2018 11:39:38.285 AM</td><td>733</td><td>100</td></tr><tr><td>19</td><td>SR / Deliverables</td><td>CUSTOMER 2</td><td>2018-02-28</td><td>28-02-2018 11:39:38.349 AM</td><td>28-02-2018 11:39:38.395 AM</td><td>46</td><td>100</td></tr><tr><td>20</td><td>Transaction Timeline</td><td>CUSTOMER 2</td><td>2018-02-28</td><td>28-02-2018 11:39:38.395 AM</td><td>28-02-2018 11:39:38.458 AM</td><td>63</td><td>100</td></tr><tr><td>21</td><td>Upcoming Events</td><td>CUSTOMER 2</td><td>2018-02-28</td><td>28-02-2018 11:39:38.473 AM</td><td>28-02-2018 11:39:38.505 AM</td><td>32</td><td>100</td></tr><tr class=blink><td>22</td><td>Spending Analysis (+ Spending Overview)</td><td>CUSTOMER 2</td><td>2018-02-28</td><td>28-02-2018 11:39:38.520 AM</td><td>28-02-2018 11:39:39.924 AM</td><td>1404</td><td>100</td></tr><tr class=blink><td>23</td><td>Category Master</td><td>CUSTOMER 2</td><td>2018-02-28</td><td>28-02-2018 11:39:40.003 AM</td><td>28-02-2018 11:39:54.640 AM</td><td>14637</td><td>100</td></tr><tr><td>24</td><td>Recommendation</td><td>CUSTOMER 2</td><td>2018-02-28</td><td>28-02-2018 11:39:54.766 AM</td><td>28-02-2018 11:39:54.813 AM</td><td>47</td><td>100</td></tr><tr><td>25</td><td>Credit Card</td><td>CUSTOMER 3</td><td>2018-02-28</td><td>28-02-2018 11:39:54.828 AM</td><td>28-02-2018 11:39:54.891 AM</td><td>63</td><td>100</td></tr><tr class=blink><td>26</td><td>Dashboard (Discover New)</td><td>CUSTOMER 3</td><td>2018-02-28</td><td>28-02-2018 11:39:54.906 AM</td><td>28-02-2018 11:39:55.296 AM</td><td>390</td><td>100</td></tr><tr><td>27</td><td>SR / Deliverables</td><td>CUSTOMER 3</td><td>2018-02-28</td><td>28-02-2018 11:39:55.343 AM</td><td>28-02-2018 11:39:55.390 AM</td><td>47</td><td>100</td></tr><tr><td>28</td><td>Transaction Timeline</td><td>CUSTOMER 3</td><td>2018-02-28</td><td>28-02-2018 11:39:55.406 AM</td><td>28-02-2018 11:39:55.484 AM</td><td>78</td><td>100</td></tr><tr><td>29</td><td>Upcoming Events</td><td>CUSTOMER 3</td><td>2018-02-28</td><td>28-02-2018 11:39:55.499 AM</td><td>28-02-2018 11:39:55.530 AM</td><td>31</td><td>100</td></tr><tr class=blink><td>30</td><td>Spending Analysis (+ Spending Overview)</td><td>CUSTOMER 3</td><td>2018-02-28</td><td>28-02-2018 11:39:55.546 AM</td><td>28-02-2018 11:39:56.747 AM</td><td>1201</td><td>100</td></tr><tr class=blink><td>31</td><td>Category Master</td><td>CUSTOMER 3</td><td>2018-02-28</td><td>28-02-2018 11:39:56.795 AM</td><td>28-02-2018 11:40:11.353 AM</td><td>14558</td><td>100</td></tr><tr><td>32</td><td>Recommendation</td><td>CUSTOMER 3</td><td>2018-02-28</td><td>28-02-2018 11:40:11.385 AM</td><td>28-02-2018 11:40:11.432 AM</td><td>47</td><td>100</td></tr><tr><td>33</td><td>Credit Card</td><td>CUSTOMER 4</td><td>2018-02-28</td><td>28-02-2018 11:40:11.432 AM</td><td>28-02-2018 11:40:11.479 AM</td><td>47</td><td>100</td></tr><tr class=blink><td>34</td><td>Dashboard (Discover New)</td><td>CUSTOMER 4</td><td>2018-02-28</td><td>28-02-2018 11:40:11.494 AM</td><td>28-02-2018 11:40:11.931 AM</td><td>437</td><td>100</td></tr><tr><td>35</td><td>SR / Deliverables</td><td>CUSTOMER 4</td><td>2018-02-28</td><td>28-02-2018 11:40:11.978 AM</td><td>28-02-2018 11:40:12.009 AM</td><td>31</td><td>100</td></tr><tr><td>36</td><td>Transaction Timeline</td><td>CUSTOMER 4</td><td>2018-02-28</td><td>28-02-2018 11:40:12.025 AM</td><td>28-02-2018 11:40:12.103 AM</td><td>78</td><td>100</td></tr><tr><td>37</td><td>Upcoming Events</td><td>CUSTOMER 4</td><td>2018-02-28</td><td>28-02-2018 11:40:12.103 AM</td><td>28-02-2018 11:40:12.150 AM</td><td>47</td><td>100</td></tr><tr class=blink><td>38</td><td>Spending Analysis (+ Spending Overview)</td><td>CUSTOMER 4</td><td>2018-02-28</td><td>28-02-2018 11:40:12.165 AM</td><td>28-02-2018 11:40:12.871 AM</td><td>706</td><td>100</td></tr><tr class=blink><td>39</td><td>Category Master</td><td>CUSTOMER 4</td><td>2018-02-28</td><td>28-02-2018 11:40:12.996 AM</td><td>28-02-2018 11:40:27.569 AM</td><td>14573</td><td>100</td></tr><tr><td>40</td><td>Recommendation</td><td>CUSTOMER 4</td><td>2018-02-28</td><td>28-02-2018 11:40:27.711 AM</td><td>28-02-2018 11:40:27.757 AM</td><td>46</td><td>100</td></tr><tr class=blink><td>41</td><td>Credit Card</td><td>CUSTOMER 5</td><td>2018-02-28</td><td>28-02-2018 11:40:27.773 AM</td><td>28-02-2018 11:40:28.007 AM</td><td>234</td><td>100</td></tr><tr class=blink><td>42</td><td>Dashboard (Discover New)</td><td>CUSTOMER 5</td><td>2018-02-28</td><td>28-02-2018 11:40:28.038 AM</td><td>28-02-2018 11:40:28.272 AM</td><td>234</td><td>100</td></tr><tr><td>43</td><td>SR / Deliverables</td><td>CUSTOMER 5</td><td>2018-02-28</td><td>28-02-2018 11:40:28.335 AM</td><td>28-02-2018 11:40:28.366 AM</td><td>31</td><td>100</td></tr><tr><td>44</td><td>Transaction Timeline</td><td>CUSTOMER 5</td><td>2018-02-28</td><td>28-02-2018 11:40:28.366 AM</td><td>28-02-2018 11:40:28.428 AM</td><td>62</td><td>100</td></tr><tr><td>45</td><td>Upcoming Events</td><td>CUSTOMER 5</td><td>2018-02-28</td><td>28-02-2018 11:40:28.428 AM</td><td>28-02-2018 11:40:28.475 AM</td><td>47</td><td>100</td></tr><tr class=blink><td>46</td><td>Spending Analysis (+ Spending Overview)</td><td>CUSTOMER 5</td><td>2018-02-28</td><td>28-02-2018 11:40:28.506 AM</td><td>28-02-2018 11:40:29.785 AM</td><td>1279</td><td>100</td></tr><tr class=blink><td>47</td><td>Category Master</td><td>CUSTOMER 5</td><td>2018-02-28</td><td>28-02-2018 11:40:29.818 AM</td><td>28-02-2018 11:40:44.425 AM</td><td>14607</td><td>100</td></tr><tr><td>48</td><td>Recommendation</td><td>CUSTOMER 5</td><td>2018-02-28</td><td>28-02-2018 11:40:44.568 AM</td><td>28-02-2018 11:40:44.612 AM</td><td>44</td><td>100</td></tr><tr class=blink><td>49</td><td>Credit Card</td><td>CUSTOMER 6</td><td>2018-02-28</td><td>28-02-2018 11:40:44.685 AM</td><td>28-02-2018 11:40:45.072 AM</td><td>387</td><td>100</td></tr><tr class=blink><td>50</td><td>Dashboard (Discover New)</td><td>CUSTOMER 6</td><td>2018-02-28</td><td>28-02-2018 11:40:45.167 AM</td><td>28-02-2018 11:40:45.786 AM</td><td>619</td><td>100</td></tr><tr><td>51</td><td>SR / Deliverables</td><td>CUSTOMER 6</td><td>2018-02-28</td><td>28-02-2018 11:40:45.838 AM</td><td>28-02-2018 11:40:45.883 AM</td><td>45</td><td>100</td></tr><tr><td>52</td><td>Transaction Timeline</td><td>CUSTOMER 6</td><td>2018-02-28</td><td>28-02-2018 11:40:45.921 AM</td><td>28-02-2018 11:40:45.996 AM</td><td>75</td><td>100</td></tr><tr><td>53</td><td>Upcoming Events</td><td>CUSTOMER 6</td><td>2018-02-28</td><td>28-02-2018 11:40:46.014 AM</td><td>28-02-2018 11:40:46.048 AM</td><td>34</td><td>100</td></tr><tr class=blink><td>54</td><td>Spending Analysis (+ Spending Overview)</td><td>CUSTOMER 6</td><td>2018-02-28</td><td>28-02-2018 11:40:46.101 AM</td><td>28-02-2018 11:40:47.914 AM</td><td>1813</td><td>100</td></tr><tr class=blink><td>55</td><td>Category Master</td><td>CUSTOMER 6</td><td>2018-02-28</td><td>28-02-2018 11:40:47.980 AM</td><td>28-02-2018 11:41:02.553 AM</td><td>14573</td><td>100</td></tr><tr><td>56</td><td>Recommendation</td><td>CUSTOMER 6</td><td>2018-02-28</td><td>28-02-2018 11:41:02.677 AM</td><td>28-02-2018 11:41:02.716 AM</td><td>39</td><td>100</td></tr><tr class=blink><td>57</td><td>Credit Card</td><td>CUSTOMER 7</td><td>2018-02-28</td><td>28-02-2018 11:41:02.735 AM</td><td>28-02-2018 11:41:03.103 AM</td><td>368</td><td>100</td></tr><tr class=blink><td>58</td><td>Dashboard (Discover New)</td><td>CUSTOMER 7</td><td>2018-02-28</td><td>28-02-2018 11:41:03.144 AM</td><td>28-02-2018 11:41:03.489 AM</td><td>345</td><td>100</td></tr><tr><td>59</td><td>SR / Deliverables</td><td>CUSTOMER 7</td><td>2018-02-28</td><td>28-02-2018 11:41:03.500 AM</td><td>28-02-2018 11:41:03.544 AM</td><td>44</td><td>100</td></tr><tr><td>60</td><td>Transaction Timeline</td><td>CUSTOMER 7</td><td>2018-02-28</td><td>28-02-2018 11:41:03.568 AM</td><td>28-02-2018 11:41:03.629 AM</td><td>61</td><td>100</td></tr><tr><td>61</td><td>Upcoming Events</td><td>CUSTOMER 7</td><td>2018-02-28</td><td>28-02-2018 11:41:03.660 AM</td><td>28-02-2018 11:41:03.701 AM</td><td>41</td><td>100</td></tr><tr class=blink><td>62</td><td>Spending Analysis (+ Spending Overview)</td><td>CUSTOMER 7</td><td>2018-02-28</td><td>28-02-2018 11:41:03.718 AM</td><td>28-02-2018 11:41:05.395 AM</td><td>1677</td><td>100</td></tr><tr class=blink><td>63</td><td>Category Master</td><td>CUSTOMER 7</td><td>2018-02-28</td><td>28-02-2018 11:41:05.447 AM</td><td>28-02-2018 11:41:20.010 AM</td><td>14563</td><td>100</td></tr><tr><td>64</td><td>Recommendation</td><td>CUSTOMER 7</td><td>2018-02-28</td><td>28-02-2018 11:41:20.093 AM</td><td>28-02-2018 11:41:20.139 AM</td><td>46</td><td>100</td></tr><tr class=blink><td>65</td><td>Credit Card</td><td>CUSTOMER 8</td><td>2018-02-28</td><td>28-02-2018 11:41:20.165 AM</td><td>28-02-2018 11:41:20.464 AM</td><td>299</td><td>100</td></tr><tr class=blink><td>66</td><td>Dashboard (Discover New)</td><td>CUSTOMER 8</td><td>2018-02-28</td><td>28-02-2018 11:41:20.473 AM</td><td>28-02-2018 11:41:20.935 AM</td><td>462</td><td>100</td></tr><tr><td>67</td><td>SR / Deliverables</td><td>CUSTOMER 8</td><td>2018-02-28</td><td>28-02-2018 11:41:21.010 AM</td><td>28-02-2018 11:41:21.044 AM</td><td>34</td><td>100</td></tr><tr><td>68</td><td>Transaction Timeline</td><td>CUSTOMER 8</td><td>2018-02-28</td><td>28-02-2018 11:41:21.055 AM</td><td>28-02-2018 11:41:21.105 AM</td><td>50</td><td>100</td></tr><tr><td>69</td><td>Upcoming Events</td><td>CUSTOMER 8</td><td>2018-02-28</td><td>28-02-2018 11:41:21.116 AM</td><td>28-02-2018 11:41:21.155 AM</td><td>39</td><td>100</td></tr><tr class=blink><td>70</td><td>Spending Analysis (+ Spending Overview)</td><td>CUSTOMER 8</td><td>2018-02-28</td><td>28-02-2018 11:41:21.164 AM</td><td>28-02-2018 11:41:22.017 AM</td><td>853</td><td>100</td></tr><tr class=blink><td>71</td><td>Category Master</td><td>CUSTOMER 8</td><td>2018-02-28</td><td>28-02-2018 11:41:22.088 AM</td><td>28-02-2018 11:41:36.655 AM</td><td>14567</td><td>100</td></tr><tr><td>72</td><td>Recommendation</td><td>CUSTOMER 8</td><td>2018-02-28</td><td>28-02-2018 11:41:36.793 AM</td><td>28-02-2018 11:41:36.846 AM</td><td>53</td><td>100</td></tr><tr><td>73</td><td>Credit Card</td><td>CUSTOMER 9</td><td>2018-02-28</td><td>28-02-2018 11:41:36.882 AM</td><td>28-02-2018 11:41:36.927 AM</td><td>45</td><td>100</td></tr><tr class=blink><td>74</td><td>Dashboard (Discover New)</td><td>CUSTOMER 9</td><td>2018-02-28</td><td>28-02-2018 11:41:36.938 AM</td><td>28-02-2018 11:41:37.563 AM</td><td>625</td><td>100</td></tr><tr><td>75</td><td>SR / Deliverables</td><td>CUSTOMER 9</td><td>2018-02-28</td><td>28-02-2018 11:41:37.598 AM</td><td>28-02-2018 11:41:37.634 AM</td><td>36</td><td>100</td></tr><tr><td>76</td><td>Transaction Timeline</td><td>CUSTOMER 9</td><td>2018-02-28</td><td>28-02-2018 11:41:37.650 AM</td><td>28-02-2018 11:41:37.711 AM</td><td>61</td><td>100</td></tr><tr><td>77</td><td>Upcoming Events</td><td>CUSTOMER 9</td><td>2018-02-28</td><td>28-02-2018 11:41:37.727 AM</td><td>28-02-2018 11:41:37.765 AM</td><td>38</td><td>100</td></tr><tr class=blink><td>78</td><td>Spending Analysis (+ Spending Overview)</td><td>CUSTOMER 9</td><td>2018-02-28</td><td>28-02-2018 11:41:37.774 AM</td><td>28-02-2018 11:41:38.520 AM</td><td>746</td><td>100</td></tr><tr class=blink><td>79</td><td>Category Master</td><td>CUSTOMER 9</td><td>2018-02-28</td><td>28-02-2018 11:41:38.594 AM</td><td>28-02-2018 11:41:53.162 AM</td><td>14568</td><td>100</td></tr><tr><td>80</td><td>Recommendation</td><td>CUSTOMER 9</td><td>2018-02-28</td><td>28-02-2018 11:41:53.193 AM</td><td>28-02-2018 11:41:53.240 AM</td><td>47</td><td>100</td></tr></table> </body> </html>";
		sendMail(message);
	}

	// HTTP GET request
	private Map<String,Long> sendGet(String url) throws Exception {

		Map<String,Long> responseMap = new HashMap<String,Long>();
		SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
		    public boolean isTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
		        return true;
		    }
		}).build();
		HostnameVerifier hostnameVerifier = SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER;

		SSLConnectionSocketFactory sslSocketFactory = new SSLConnectionSocketFactory(sslContext, hostnameVerifier);
		Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory>create()
		        .register("http", PlainConnectionSocketFactory.getSocketFactory())
		        .register("https", sslSocketFactory)
		        .build();

		// allows multi-threaded use
		PoolingHttpClientConnectionManager connMgr = new PoolingHttpClientConnectionManager( socketFactoryRegistry);


		//System.out.println(url);
		HttpClient client = HttpClients.custom()
						.setSslcontext(sslContext)
						.setSSLHostnameVerifier(new AllowAllHostnameVerifier())
		                .setConnectionManager(connMgr)
		                .build();

		HttpGet request = new HttpGet(url);

		long startTime = new Date().getTime();
		HttpResponse response = client.execute(request);
		long endTime = new Date().getTime();
		long difference =endTime-startTime;
		responseMap.put("startTime", startTime);
		responseMap.put("endTime", endTime);
		responseMap.put("difference", difference);
		/*
		System.out.println("Time Difference:- "+difference);
		System.out.println("Response Code : " +response.getStatusLine().getStatusCode());
		BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
		StringBuffer result = new StringBuffer();
		String line = "";
		while ((line = rd.readLine()) != null) {
			result.append(line);
		}
		System.out.println(result.toString());
		*/
		return responseMap;
	}
	
	public static void write(String text){
		String localPath="C:/Users/BAN97267/Desktop/test1.html";
		String serverPath="/vertica_load/amaze_api_performance_monitor/performance.html";
		
		//File file = new File(localPath);
		File file = new File(serverPath);
        FileWriter fr = null;
        try {
            fr = new FileWriter(file);
            fr.write(text);
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            try {
                fr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
	}
	public static void sendMail(String message) {

        StringBuffer bf = new StringBuffer();
        try {
        	System.out.println("Sending Mail");
        	//System.out.println(message);
        	String toAddr = "mbsupport@icicibank.com, sasikumar.r@ext.icicibank.com, shriram.perumal@icicibank.com, shashank.gangadharbhatla@icicibank.com, debashish.barai@icicibank.com, ashrumochan.behera@ext.icicibank.com,mongosupport@icicibank.com";
        	//String toAddr = "debashish.barai@icicibank.com, ashrumochan.behera@ext.icicibank.com";
        	//String toAddr = "ashrumochan.behera@ext.icicibank.com";
            /*Process p = Runtime.getRuntime().exec(new String[] { "bash", "-c", "( echo \"To:"+toAddr+"\";"
                            //+ "    echo \"Cc:shriram.perumal@icicibank.com \";" 
                            + "    echo \"Subject: iMobile NXT - API Response Time log \";"
                            + "    echo \"Content-Type: text/html\";" 
                            + "    echo \"MIME-Version: 1.0\";"
                            + "    echo \""+message+"\""  
                            + " ) | sendmail -t " });*/
            Process p = Runtime.getRuntime().exec(new String[] { "bash", "-c", "( echo \"To:"+toAddr+"\";"
                    //+ "    echo \"Cc:shriram.perumal@icicibank.com \";" 
                    + "    echo \"Subject: Alert: iMobile NXT - API Response Time log \";"
                    + "    echo \"Content-Type: text/html\";" 
                    + "    echo \"MIME-Version: 1.0\";"
                    + "    echo ; "
                    + " cat /vertica_load/amaze_api_performance_monitor/performance.html"  
                    + " ) | sendmail -t " });
            BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = input.readLine()) != null) {
                bf.append(line);
            }
            System.out.println(bf.toString());
            System.out.println("Mail Send");
        } catch (IOException e) {
        	e.printStackTrace();
            System.out.println("IOException in Process");
        }
    }
}