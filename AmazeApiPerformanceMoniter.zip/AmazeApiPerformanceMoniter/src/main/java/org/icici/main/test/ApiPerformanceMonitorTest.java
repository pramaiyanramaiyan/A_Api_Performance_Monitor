package org.icici.main.test;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.AllowAllHostnameVerifier;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.BasicHttpClientConnectionManager;
import org.apache.http.impl.conn.SingleClientConnManager;
import org.apache.http.message.BasicNameValuePair;

public class ApiPerformanceMonitorTest {

	private final String USER_AGENT = "Mozilla/5.0";

	public static void main(String[] args) throws Exception {

		ApiPerformanceMonitorTest http = new ApiPerformanceMonitorTest();
		String arr[]=new String[]{ "https://imnxtanalytics.icicibankltd.com/amaze/rest/api/getDashboard?USERID=ABCDEF&RRN=123123&CHANNEL=abc&MOBILE=123456789",
									"https://imnxtanalytics.icicibankltd.com/amaze/rest/api/getOverview?USERID=ABCDEF&RRN=123123&CHANNEL=abc&MOBILE=123456789",
									"https://imnxtanalytics.icicibankltd.com/amaze/rest/api/getRecommendation?USERID=ABCDEF&RRN=123123&CHANNEL=abc&MOBILE=123456789",
									"https://imnxtanalytics.icicibankltd.com/amaze/rest/api/getUpcomingTransactions?USERID=ABCDEF&RRN=123123&CHANNEL=abc&MOBILE=123456789",
									"https://imnxtanalytics.icicibankltd.com/amaze/rest/api/getSRStatus?USERID=ABCDEF&RRN=123123&CHANNEL=abc&MOBILE=123456789",
									"https://imnxtanalytics.icicibankltd.com/amaze/rest/api/getTransactions?USERID=ABCDEF&RRN=123123&CHANNEL=abc&MOBILE=123456789",
									"https://imnxtanalytics.icicibankltd.com/amaze/rest/api/getCategoryList?USERID=ABCDEF&RRN=123123&CHANNEL=abc&MOBILE=123456789",
									"https://imnxtanalytics.icicibankltd.com/amaze/rest/api/updateCategory?USERID=ABCDEF&RRN=123123&CHANNEL=abc&MOBILE=123456789"};

		System.out.println("Testing 1 - Send Http GET request");
		for(String s : arr){
			//System.out.println(new Date().getTime());
			http.sendGet(s);
		}
	}

	// HTTP GET request
	private void sendGet(String url) throws Exception {
		SSLContext sslContext = SSLContext.getInstance("SSL");

		// set up a TrustManager that trusts everything
		sslContext.init(null, new TrustManager[] { new X509TrustManager() {
		            public X509Certificate[] getAcceptedIssuers() {
		                    System.out.println("getAcceptedIssuers =============");
		                    return null;
		            }

		            public void checkClientTrusted(X509Certificate[] certs,
		                            String authType) {
		                    System.out.println("checkClientTrusted =============");
		            }

		            public void checkServerTrusted(X509Certificate[] certs,
		                            String authType) {
		                    System.out.println("checkServerTrusted =============");
		            }
		} }, new SecureRandom());

		SSLSocketFactory sf = new SSLSocketFactory(sslContext);
		Scheme httpsScheme = new Scheme("https", 443, sf);
		SchemeRegistry schemeRegistry = new SchemeRegistry();
		schemeRegistry.register(httpsScheme);
		// apache HttpClient version >4.2 should use BasicClientConnectionManager
		ClientConnectionManager cm = new SingleClientConnManager(schemeRegistry);

		System.out.println(url);
		HttpHost myProxy = new HttpHost("proxylb.icicibankltd.com", 80);
		CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
		credentialsProvider.setCredentials(new AuthScope(myProxy), new UsernamePasswordCredentials("BAN97267", "Apr@2018"));
		HttpClient client = HttpClients.custom()
						.setSslcontext(sslContext)
						.setSSLHostnameVerifier(new AllowAllHostnameVerifier())
		                .setConnectionManager(new BasicHttpClientConnectionManager())
		                .setProxy(myProxy)
		                .setDefaultCredentialsProvider(credentialsProvider)                    
		                .build();

		HttpGet request = new HttpGet(url);

		System.out.println(new Date().getTime()+" "+request.getURI());
		HttpResponse response = client.execute(request);
		System.out.println(new Date().getTime());
		System.out.println("Response Code : " +response.getStatusLine().getStatusCode());
		BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
		StringBuffer result = new StringBuffer();
		String line = "";
		while ((line = rd.readLine()) != null) {
			result.append(line);
		}
		System.out.println(result.toString());
	}

	// HTTP POST request
	private void sendPost() throws Exception {

		String url = "https://selfsolve.apple.com/wcResults.do";

		HttpClient client = new DefaultHttpClient();
		HttpPost post = new HttpPost(url);

		// add header
		post.setHeader("User-Agent", USER_AGENT);

		List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
		urlParameters.add(new BasicNameValuePair("sn", "C02G8416DRJM"));
		urlParameters.add(new BasicNameValuePair("cn", ""));
		urlParameters.add(new BasicNameValuePair("locale", ""));
		urlParameters.add(new BasicNameValuePair("caller", ""));
		urlParameters.add(new BasicNameValuePair("num", "12345"));

		post.setEntity(new UrlEncodedFormEntity(urlParameters));

		HttpResponse response = client.execute(post);
		System.out.println("\nSending 'POST' request to URL : " + url);
		System.out.println("Post parameters : " + post.getEntity());
		System.out.println("Response Code : " +
                                    response.getStatusLine().getStatusCode());

		BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

		StringBuffer result = new StringBuffer();
		String line = "";
		while ((line = rd.readLine()) != null) {
			result.append(line);
		}

		System.out.println(result.toString());

	}
}