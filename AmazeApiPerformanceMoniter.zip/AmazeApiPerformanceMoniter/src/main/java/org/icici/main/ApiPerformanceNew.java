package org.icici.main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.SocketTimeoutException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.AllowAllHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.icici.db.DatabaseConnection;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/*
 * This is the main class used now.
 * The process aims to perform a API performance test
 */
public class ApiPerformanceNew {
	
	public static int threshhold=1000;
	
	public static JsonObject getServerStatus(String key,String url,String mappedUser) {
		
		JsonObject responseObj = new JsonObject();
		long startTime = 0L;
		long endTime = 0L;
		try{
		SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
		    public boolean isTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
		        return true;
		    }
		}).build();
		HostnameVerifier hostnameVerifier = SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER;

		SSLConnectionSocketFactory sslSocketFactory = new SSLConnectionSocketFactory(sslContext, hostnameVerifier);
		Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory>create()
		        .register("http", PlainConnectionSocketFactory.getSocketFactory())
		        .register("https", sslSocketFactory)
		        .build();

		RequestConfig requestConfig = RequestConfig.custom()
				  //.setConnectTimeout(3000)  //Server Timeout time
				  //.setSocketTimeout(100)
				  .build();
		
		HttpClient client = HttpClients.custom()
				.setSslcontext(sslContext)
				.setSSLHostnameVerifier(new AllowAllHostnameVerifier())
				.setDefaultRequestConfig(requestConfig)
                //.setConnectionManager(connMgr)
                .build();
		
		HttpGet request = new HttpGet(url);
		
		startTime = new Date().getTime();
		responseObj.addProperty("mapped_user", mappedUser);
		responseObj.addProperty("api", key);
		responseObj.addProperty("start_time", startTime);
		HttpResponse response = client.execute(request);		
		endTime = new Date().getTime();
		String apiResponse = IOUtils.toString(response.getEntity().getContent());
		
		JsonObject responseJson = new JsonParser().parse(apiResponse).getAsJsonObject();
		
		
		responseObj.addProperty("end_time", endTime);
		responseObj.addProperty("difference", endTime - startTime);
		responseObj.add("response", responseJson);
		//System.out.println(responseObj);
		if(responseJson.get("STATUS").getAsInt()==500){
			if(responseJson.get("ERROR_CODE").getAsString().equalsIgnoreCase("E01"))			
			{
				responseObj.addProperty("timeout", true);
			}
			else if(responseJson.get("ERROR_CODE").getAsString().equalsIgnoreCase("E02"))
			{
				if(key.equalsIgnoreCase("SR / Deliverables")
						||key.equalsIgnoreCase("Recommendation")
						||key.equalsIgnoreCase("Upcoming Events")
						||key.equalsIgnoreCase("Credit Card"))
				{
					responseObj.addProperty("data_count", 1);
				}
				else{
					responseObj.addProperty("data_count", 0);
				}				
				responseObj.addProperty("timeout", false);
			}
			else if(responseJson.get("ERROR_CODE").getAsString().equalsIgnoreCase("E03"))
			{
				responseObj.addProperty("data_count", 0);
				responseObj.addProperty("timeout", false);
			}
		}else{
			responseObj.addProperty("timeout", false);
			responseObj.addProperty("data_count", 1);
		}
		
		responseObj.addProperty("serverDown", false);
		
		}
		catch(ConnectTimeoutException | SocketTimeoutException cte){
			//System.out.println("Connection Timeout");
			responseObj.addProperty("timeout", true);
			responseObj.addProperty("end_time", new Date().getTime());
			responseObj.addProperty("error_message", cte.getLocalizedMessage());
			responseObj.addProperty("serverDown", false);
		}
		catch(HttpHostConnectException cr){
			System.out.println(cr.getLocalizedMessage());
			responseObj.addProperty("serverDown", true);
			responseObj.addProperty("end_time", new Date().getTime());
			responseObj.addProperty("error_message", cr.getLocalizedMessage());
			responseObj.addProperty("timeout", false);
		}catch(KeyManagementException | NoSuchAlgorithmException |KeyStoreException| IOException ex){
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
		return responseObj;
	}
	
	public static void main(String[] args) {
		System.out.println("Start Time :- "+new Date());
		JsonArray responseArray = new JsonArray();
		boolean serverDown =false;
		boolean timeOut =false;
		boolean dataCount =false;
		StringBuffer generalMailResponse = new StringBuffer();
		StringBuffer serverDownMailResponse = new StringBuffer();
		StringBuffer timeoutMailResponse = new StringBuffer();
		StringBuffer dataCountMailResponse = new StringBuffer();
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss.SSS a");
		int generalCount = 0;
		int dataCountCounter = 0;
		int timeOutCount = 0;
		int serverDownCount = 0;
		try{
			Connection con = DatabaseConnection.getConnction();
			//Connection updateCon = DatabaseConnection.getConnction();
			
			Map<String,String> urlMapping = new HashMap<String,String>();
			urlMapping.put("Dashboard (Discover New)","https://imnxtanalytics.icicibank.com/amaze/rest/api/getDashboard?USERID={0}&RRN=123123&CHANNEL=abc&MOBILE=123456789");
			urlMapping.put("Spending Analysis (+ Spending Overview)","https://imnxtanalytics.icicibank.com/amaze/rest/api/getOverview?USERID={0}&RRN=123123&CHANNEL=abc&MOBILE=123456789");
			urlMapping.put("Recommendation","https://imnxtanalytics.icicibank.com/amaze/rest/api/getRecommendation?USERID={0}&RRN=123123&CHANNEL=abc&MOBILE=123456789");
			urlMapping.put("Upcoming Events","https://imnxtanalytics.icicibank.com/amaze/rest/api/getUpcomingTransactions?USERID={0}&RRN=123123&CHANNEL=abc&MOBILE=123456789");
			urlMapping.put("SR / Deliverables","https://imnxtanalytics.icicibank.com/amaze/rest/api/getSRStatus?USERID={0}&RRN=123123&CHANNEL=abc&MOBILE=123456789");
			urlMapping.put("Transaction Timeline","https://imnxtanalytics.icicibank.com/amaze/rest/api/getTransactions?USERID={0}&RRN=123123&CHANNEL=abc&MOBILE=123456789");
			urlMapping.put("Category Master","https://imnxtanalytics.icicibank.com/amaze/rest/api/getCategoryList?USERID={0}&RRN=123123&CHANNEL=abc&MOBILE=123456789");
			urlMapping.put("Credit Card", "https://imnxtanalytics.icicibank.com/amaze/rest/api/getCreditCardOverview?USERID={0}&RRN=123123&CHANNEL=abc&MOBILE=123456789");
			
			String query = "select USER_ID,MAPPING_ID from EDW.AMAZE_SAS_DASHBOARD_MAPPING ";
			String condition = " where MAPPING_ID in('CUSTOMER 1', 'CUSTOMER 2', 'CUSTOMER 3', 'CUSTOMER 4', 'CUSTOMER 5', 'CUSTOMER 6', 'CUSTOMER 7', 'CUSTOMER 8', 'CUSTOMER 9','CUSTOMER 10') order by mapping_id";
			
			//String condition = " where MAPPING_ID in('CUSTOMER 2') order by mapping_id";
			ResultSet rs = DatabaseConnection.getResult(query+condition, con);
			query = "insert into EDW.AMAZE_API_PERFORMANCE_HISTORY values(?, ?, ? ,?, ?, ?, ?)";
			
			
			while(rs.next()){
				String user = rs.getString("USER_ID");
				String mappedUser = rs.getString("MAPPING_ID");
				
/*				String user = "523180407";
				String mappedUser = "hello";*/
				
				for(String key : urlMapping.keySet()){
					responseArray.add(getServerStatus(key,MessageFormat.format(urlMapping.get(key),user),mappedUser));
				}			
			}
			rs.close();
			//System.out.println(responseArray);
			PreparedStatement ps = con.prepareStatement(query);
			
			for(JsonElement e : responseArray){			
				//System.out.println(e);
				JsonObject response =e.getAsJsonObject(); 
				//System.out.println(response);
				//System.out.println("Data Count:- "+response.get("data_count").getAsInt());
				//System.out.println(response.has("timeout"));
				/*boolean b = response.get("timeout").getAsBoolean();
				if(!b){
					JsonObject obj = response.get("response").getAsJsonObject();
					System.out.println(obj);
				}*/
				//Check Server Status on/off
				if(response.get("serverDown").getAsBoolean())
				{
					serverDownMailResponse.append("\n<tr><td>"+(serverDownCount+1)
							+"</td><td>"+response.get("api").getAsString()
							+"</td><td>"+ response.get("mapped_user").getAsString()
							+"</td><td>"+dateFormat.format(new Date(response.get("start_time").getAsLong()))
							+"</td><td>"+dateFormat.format(new Date(response.get("end_time").getAsLong()))
							+"</td><td>"+response.get("error_message").getAsString()
							+"</td></tr>");
					serverDown =true;
					serverDownCount++;
				}else if(response.get("timeout").getAsBoolean()){ 
					timeoutMailResponse.append("\n<tr><td>"+(timeOutCount+1)
							+"</td><td>"+response.get("api").getAsString()
							+"</td><td>"+ response.get("mapped_user").getAsString()
							+"</td><td>"+dateFormat.format(new Date(response.get("start_time").getAsLong()))
							+"</td><td>"+dateFormat.format(new Date(response.get("end_time").getAsLong()))
							+"</td><td>"+response.get("error_message").getAsString()
							+"</td></tr>");
					timeOut =true;
					timeOutCount++;
				}else if(response.get("data_count").getAsInt()==0){
					dataCountMailResponse.append("\n<tr><td>"+(dataCountCounter+1)
							+"</td><td>"+response.get("api").getAsString()
							+"</td><td>"+ response.get("mapped_user").getAsString()
							+"</td><td>"+dateFormat.format(new Date(response.get("start_time").getAsLong()))
							+"</td><td>"+dateFormat.format(new Date(response.get("end_time").getAsLong()))
							+"</td><td>"+" "
							+"</td></tr>");
					dataCount =true;
					dataCountCounter++;
					ps.setString(1, response.get("api").getAsString());
					ps.setString(2, response.get("mapped_user").getAsString());
					ps.setDate(3, new java.sql.Date(new Date().getTime()));
					ps.setTimestamp(4, new java.sql.Timestamp(response.get("start_time").getAsLong()));
					ps.setTimestamp(5, new java.sql.Timestamp(response.get("end_time").getAsLong()));
					ps.setLong(6, response.get("difference").getAsLong());
					ps.setInt(7, threshhold);
					ps.addBatch();
				}/*else if( ( response.get("api").getAsString().equalsIgnoreCase("Spending Analysis (+ Spending Overview)") 
								&& response.get("difference").getAsLong()>500L) 
							||(!response.get("api").getAsString().equalsIgnoreCase("Spending Analysis (+ Spending Overview)") 
								&& response.get("difference").getAsLong()>200L)) */
				else if(response.get("difference").getAsLong()>threshhold) 
				{
					generalMailResponse.append("\n<tr><td>"+(generalCount+1)
							+"</td><td>"+response.get("api").getAsString()
							+"</td><td>"+ response.get("mapped_user").getAsString()
							+"</td><td>"+dateFormat.format(new Date(response.get("start_time").getAsLong()))
							+"</td><td>"+dateFormat.format(new Date(response.get("end_time").getAsLong()))
							+"</td><td>"+response.get("difference").getAsInt()
							+"</td><td>"+threshhold+"</td></tr>");
					generalCount++;
					ps.setString(1, response.get("api").getAsString());
					ps.setString(2, response.get("mapped_user").getAsString());
					ps.setDate(3, new java.sql.Date(new Date().getTime()));
					ps.setTimestamp(4, new java.sql.Timestamp(response.get("start_time").getAsLong()));
					ps.setTimestamp(5, new java.sql.Timestamp(response.get("end_time").getAsLong()));
					ps.setLong(6, response.get("difference").getAsLong());
					ps.setInt(7, threshhold);
					ps.addBatch();
				}else {
					System.out.println("Success :: "+response.get("mapped_user").getAsString()+" for :: "+response.get("api").getAsString());
					ps.setString(1, response.get("api").getAsString());
					ps.setString(2, response.get("mapped_user").getAsString());
					ps.setDate(3, new java.sql.Date(new Date().getTime()));
					ps.setTimestamp(4, new java.sql.Timestamp(response.get("start_time").getAsLong()));
					ps.setTimestamp(5, new java.sql.Timestamp(response.get("end_time").getAsLong()));
					ps.setLong(6, response.get("difference").getAsLong());
					ps.setInt(7, threshhold);
					ps.addBatch();
				}
			}
			
			ps.executeBatch();
			
			//Sending Mail
			if(serverDownCount>0)
			{
				System.out.println("Server Down Mail");
				sendServerDownMail(serverDownMailResponse.toString());
			}else if(timeOut && timeOutCount>0){
				System.out.println("Time Out Mail");
				sendTimeOutMail(timeoutMailResponse.toString());
			}else if(dataCount && dataCountCounter>0){
				System.out.println("Data Count Mail");
				sendDataCountMail(dataCountMailResponse.toString());
			}else if(generalCount>0) {
				System.out.println("General Mail");
				sendGeneralMail(generalMailResponse.toString());
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		System.out.println("End Time :- "+new Date());
				
	}
	
	public static void sendServerDownMail(String message){
		String subject = " iMobileNXT - API Not accessible ";
		String toAddr = "mbsupport@icicibank.com, btoappsupport@icicibank.com, mongosupport@icicibank.com, debashish.barai@icicibank.com, vidya.sawant@ext.icicibank.com, sasikumar.r@ext.icicibank.com, ashrumochan.behera@ext.icicibank.com, vijay.pati@ext.icicibank.com, stuti.rajvanshi@icicibank.com";
		StringBuffer mailResponse = new StringBuffer();
		mailResponse.append("<html> \n <head> <style>table {     background: white;     border: 1px solid black;     border-collapse: collapse;     border-color: black;     border-spacing: 1px; 	     font-family: Calibri; } th {         border: 2px solid black;     background-color: #000066; 	     color: white; 	     padding: 3px     } tr td{         border: 1px solid black;     color: black; 	     padding: 3px; text-align: center;     }</style> \n</head> \n<body> \n"
				+ " <p> Dear All, \n<br><br>&emsp;&emsp;Please check the below APIs on priority. API is not reachable or down. Check on high priority. "
				+" </p> "
				+ " \n<table>    <tr>     <th>#</th>     <th>API</th>     <th>User ID</th><th>Start Time</th> 	<th>End Time</th> 	<th> Error Received (if any)</th></tr>");
		mailResponse.append(message);
		mailResponse.append("\n</table> \n <p style=\"color:gray\"><br>Thanks and Regards,<br>Big Data Team</p></body> \n</html>");
		sendMail(mailResponse.toString(),subject,toAddr);
	}
	public static void sendTimeOutMail(String message){
		String subject = " iMobileNXT - API Timeout / No Response issue ";
		String toAddr = "mongosupport@icicibank.com, btoappsupport@icicibank.com , mbsupport@icicibank.com, debashish.barai@icicibank.com, vidya.sawant@ext.icicibank.com, sasikumar.r@ext.icicibank.com, ashrumochan.behera@ext.icicibank.com, vijay.pati@ext.icicibank.com, stuti.rajvanshi@icicibank.com";
		StringBuffer mailResponse = new StringBuffer();
		mailResponse.append("<html> \n <head> <style>table {     background: white;     border: 1px solid black;     border-collapse: collapse;     border-color: black;     border-spacing: 1px; 	     font-family: Calibri; } th {         border: 2px solid black;     background-color: #000066; 	     color: white; 	     padding: 3px     } tr td{         border: 1px solid black;     color: black; 	     padding: 3px; text-align: center;     }</style> \n</head> \n<body> \n"
				+ " <p> Dear All, \n<br><br>&emsp;&emsp;Please check the below APIs on priority. Timeout error is encountered for these APIs "
				+ " </p> "
				+ " \n<table>    <tr>     <th>#</th>     <th>API</th>     <th>User ID</th><th>Start Time</th> 	<th>End Time</th> 	<th> Error Received (if any)</th></tr>");
		mailResponse.append(message);
		mailResponse.append("\n</table> \n <p style=\"color:gray\"><br>Thanks and Regards,<br>Big Data Team</p></body> \n</html>");
		sendMail(mailResponse.toString(),subject,toAddr);
	}
	public static void sendDataCountMail(String message){
		System.out.println(message);
		String subject = " iMobileNXT - API returns zero count ";
		String toAddr = "mongosupport@icicibank.com, debashish.barai@icicibank.com, vidya.sawant@ext.icicibank.com, sasikumar.r@ext.icicibank.com, ashrumochan.behera@ext.icicibank.com, vijay.pati@ext.icicibank.com, stuti.rajvanshi@icicibank.com";
		StringBuffer mailResponse = new StringBuffer();
		mailResponse.append("<html> \n <head> <style>table {     background: white;     border: 1px solid black;     border-collapse: collapse;     border-color: black;     border-spacing: 1px; 	     font-family: Calibri; } th {         border: 2px solid black;     background-color: #000066; 	     color: white; 	     padding: 3px     } tr td{         border: 1px solid black;     color: black; 	     padding: 3px; text-align: center;     }</style> \n</head> \n<body> \n"
				+ " <p> Dear All, \n<br><br>&emsp;&emsp;Please check the below APIs on priority. API is returns zero record / count. Check on high priority. "
				+ " </p> "
				+ " \n<table>    <tr>     <th>#</th>     <th>API</th>     <th>User ID</th><th>Start Time</th> 	<th>End Time</th> 	<th> Error Received (if any)</th></tr>");
		mailResponse.append(message);
		mailResponse.append("\n</table> \n <p style=\"color:gray\"><br>Thanks and Regards,<br>Big Data Team</p></body> \n</html>");
		sendMail(mailResponse.toString(),subject,toAddr);
	}
	public static void sendGeneralMail(String message){
		String subject = " Alert: iMobile NXT - API Response Time log ";
		String toAddr = "mbsupport@icicibank.com, sasikumar.r@ext.icicibank.com, vidya.sawant@ext.icicibank.com, stuti.rajvanshi@icicibank.com, debashish.barai@icicibank.com, ashrumochan.behera@ext.icicibank.com,mongosupport@icicibank.com";
		StringBuffer mailResponse = new StringBuffer();
		mailResponse.append("<html> \n <head> <style>table {     background: white;     border: 1px solid black;     border-collapse: collapse;     border-color: black;     border-spacing: 1px; 	     font-family: Calibri; } th {         border: 2px solid black;     background-color: #000066; 	     color: white; 	     padding: 3px     } tr td{         border: 1px solid black;     color: black; 	     padding: 3px; text-align: center;     }</style> \n</head> \n<body> \n"
				+ " <p> Dear All, \n<br><br>&emsp;&emsp;Please find the iMobile NXT - API Response Time log below "
				+ " <br>&emsp;&emsp;Listed are all API's for which we need to check the reason behind high response time.</p> "
				+ " \n<table>    <tr>     <th>#</th>     <th>API</th>     <th>User ID</th><th>Start Time</th> 	<th>End Time</th> 	<th>Response Time<br>(in milli second)</th> 	<th>Benchmark time<br>(in milli second)</th>   </tr>");
		mailResponse.append(message);
		mailResponse.append("\n</table> \n <p style=\"color:gray\"><br>Thanks and Regards,<br>Big Data Team</p></body> \n</html>");
		sendMail(mailResponse.toString(),subject,toAddr);
	}
	
	public static void sendMail(String message,String subject,String toAddr) {

		//System.out.println(message);
		write(message);
        
        StringBuffer bf = new StringBuffer();
        try {
        	System.out.println("Sending Mail");
        	//System.out.println(subject);
        	//System.out.println(message);
        	//toAddr = "mbsupport@icicibank.com, sasikumar.r@ext.icicibank.com, vidya.sawant@ext.icicibank.com, shashank.gangadharbhatla@icicibank.com, debashish.barai@icicibank.com, ashrumochan.behera@ext.icicibank.com,mongosupport@icicibank.com";
        	//toAddr = "vidya.sawant@ext.icicibank.com, debashish.barai@icicibank.com, ashrumochan.behera@ext.icicibank.com";
            Process p = Runtime.getRuntime().exec(new String[] { "bash", "-c", "( echo \"To:"+toAddr+"\";"
                    + "    echo \"Subject: "+subject+" \";"
                    + "    echo \"Content-Type: text/html\";" 
                    + "    echo \"MIME-Version: 1.0\";"
                    + "    echo ; "
                    + " cat /vertica_load/amaze_api_performance_monitor/performance.html"  
                    + " ) | sendmail -t " });
            BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = input.readLine()) != null) {
                bf.append(line);
            }
            System.out.println(bf.toString());
            System.out.println("Mail Sent");
        } catch (Exception e) {
        	e.printStackTrace();
            System.out.println("IOException in Process");
        }
        
    }
	
	public static void write(String text){
		String localPath="C:/Users/BAN97267/Desktop/test1.html";
		String serverPath="/vertica_load/amaze_api_performance_monitor/performance.html";
		
		//File file = new File(localPath);
		File file = new File(serverPath);
        FileWriter fr = null;
        try {
            fr = new FileWriter(file);
            fr.write(text);
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            try {
                fr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
	}
}
