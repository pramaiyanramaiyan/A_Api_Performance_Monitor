package org.icici.db;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class DatabaseConnection {

	private static Connection con;

	static final String JDBC_DRIVER = "com.vertica.jdbc.Driver";
	//static final String DB_URL = "jdbc:vertica://10.24.155.161:5433/ICICIUATDB";
	static final String DB_URL = "jdbc:vertica://10.50.72.56:6439/ICICIDWHDB?BackupServerNode=10.50.72.56,10.50.72.66,10.50.72.57,10.50.72.67,10.50.72.58,10.50.72.68,10.50.72.59,10.50.72.69,10.50.72.60,10.50.72.70&ConnectionLoadBalance=1";

	// Database credentials
	static final String USER = "EDW";
	static final String PASS = "DwH@34517";

	public static Connection getConnction(Properties pc) throws ClassNotFoundException, SQLException, IOException {
		
		Class.forName(pc.getProperty("vertica_jdbc_driver"));
		con = DriverManager.getConnection(pc.getProperty("vertica_connection_string"), 
										  pc.getProperty("vertica_user_name"), 
										  pc.getProperty("vertica_password"));
		return con;
	}
	
	public static Connection getConnction() throws ClassNotFoundException, SQLException {

		Class.forName(JDBC_DRIVER);
		con = DriverManager.getConnection(DB_URL, USER, PASS);
		return con;
	}
	
	public static ResultSet getResult(String query,Connection con) throws ClassNotFoundException, SQLException, IOException{
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(query);
		return rs;
	}
	
	public static int update(Connection con,String query,Object... params) throws SQLException{
		Statement st=con.createStatement();
		int t = st.executeUpdate(query);
		return t;		
	}
	
	public static int delete(Connection con,String query,Object... params) throws SQLException{
		PreparedStatement pstmt=con.prepareStatement(query);
		QueryBuilder.fillStatement(pstmt, params);
		int t = pstmt.executeUpdate();
		return t;		
	}
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
	}
	
	public static int insert(Connection con,String Query,Object... params) throws SQLException{
		//System.out.println("Inside DB");
		PreparedStatement pstmt = con.prepareStatement(Query);
		//System.out.println("Prepared Statement Created");
		QueryBuilder.fillStatement(pstmt, params);
		//System.out.println("Filling Statament");
		int n = pstmt.executeUpdate();
		//System.out.println("Leaving DB");
		pstmt.close();
		return n;
	}
	
	public static ResultSet getResult(String query,Connection con,Object... params) throws ClassNotFoundException, SQLException, IOException{
		//Statement st = DatabaseConnection.getConnction("vertica").createStatement();
		PreparedStatement pstmt = con.prepareStatement(query);
		QueryBuilder.fillStatement(pstmt, params);
		ResultSet rs = pstmt.executeQuery();
		return rs;
	}

}