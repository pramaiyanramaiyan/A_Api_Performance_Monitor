package org.icici.db;

import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;

public class QueryBuilder {

	public static void fillStatement(PreparedStatement stmt, Object... params) {

		// nothing to do here
		if (params == null) {
			return;
		}

		boolean pmdNotSupported = false;

		ParameterMetaData pmd = null;
		if (!pmdNotSupported) {
			try {
				pmd = stmt.getParameterMetaData();
				//stmt.getMetaData().getTableName(column)
				if (pmd == null) { // can be returned by implementations that
					// don't support the method
					pmdNotSupported = true;
				} else {
					int stmtCount = pmd.getParameterCount();
					int paramsCount = params == null ? 0 : params.length;

					if (stmtCount != paramsCount) {
						throw new SQLException(
										"Wrong number of parameters: expected "
										+ stmtCount + ", was given "
										+ paramsCount);
					}
				}
			} catch (SQLException ex) {
				pmdNotSupported = true;
			}
		}

		for (int i = 0; i < params.length; i++) {
			if (params[i] != null) {
				try {
					stmt.setObject(i + 1, params[i]);
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} else {
				int sqlType = Types.VARCHAR;
				if (!pmdNotSupported) {
					try {
						sqlType = pmd.getParameterType(i + 1);
					} catch (SQLException e) {
						pmdNotSupported = true;
					}
				}
				try {
					stmt.setNull(i + 1, sqlType);
				} catch (SQLException e) {
					e.printStackTrace();
				} 
			}
		}
	}
	
}
